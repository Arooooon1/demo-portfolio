# Demo portfolio / Siarhei

Два самостоятельных демопроекта, созданных с помощью AI. Это не работы для реальных клиентов. Все интерьерные иллюстрации — оригинальный SVG, внешних шрифтов и CDN нет.

## Быстрый просмотр
Откройте index.html двойным щелчком. Интернет, сборка и WordPress для превью не нужны. Формы в превью ничего не отправляют и не сохраняют.

## 1. Atelier Studio
Адаптивный сайт интерьерной студии: мобильное меню, фильтр проектов, анимации появления, reduced-motion, авторские иллюстрации. Превью: 01-studio-website/preview/index.html.
WordPress: Appearance → Themes → Add New → Upload Theme → packages/atelier-studio.zip → Activate. Главная страница использует front-page.php; остальные публикации — стандартный цикл WordPress. Это исходная тема для дальнейшей адаптации, а не визуальный конструктор. Тексты концепта меняются в front-page.php. Рекомендуется свежая поддерживаемая версия WordPress и PHP.

## 2. Atelier Enquiries
Plugins → Add New → Upload Plugin → packages/atelier-enquiries.zip → Activate. Settings → Atelier Enquiries: задать email получателя. Добавить [atelier_enquiry] на страницу. Тема автоматически показывает форму при активном плагине.
Проверка nonce, валидация полей и согласия, honeypot, ограничение 1 попытки отправки в минуту по хешу IP, отправка через wp_mail. Данные заявок в базе не сохраняются; хеш IP живёт в transient около минуты. Письмо и журналы транспорта могут сохранять данные. За общим IP несколько пользователей делят лимит; это базовая защита, не полноценный антиспам. При кешировании страниц исключить форму из долгого кеша, чтобы nonce не устаревал. Указывать собственную политику обработки данных перед запуском.

## Проверка WordPress перед использованием
PHP/WordPress в этой среде не запущены: установка, nonce и реальная отправка писем требуют проверки на тестовом WordPress. Не заявлять о проверенной доставке. Проверить: активацию темы/плагина, страницу с shortcode, корректную заявку, неверный email, отсутствие согласия, короткий текст, истёкший nonce, honeypot, повтор за минуту, ошибку mail-транспорта, настройки получателя под администратором и ограничения доступа для обычного пользователя. wp_mail=true означает принятие письма транспортом, а не доставку.

## English
Open index.html for offline previews. Install the theme and plugin ZIPs from packages through the WordPress dashboard. Configure the enquiry recipient under Settings → Atelier Enquiries. Use [atelier_enquiry] on a page. Browser previews simulate submission locally; the plugin uses server validation and wp_mail on WordPress. WordPress runtime and real mail delivery must be tested on a staging installation before production. These are original self-initiated demos created with AI assistance, not client case studies.

Theme and plugin PHP: GPL-2.0-or-later. Original visual assets and preview code: MIT (see LICENSE.txt).
