# Selected demo work

## Atelier Studio — responsive service website
Self-initiated interior studio concept. Designed and implemented an editorial landing page with original SVG interiors, responsive layouts, project filters, accessible navigation and motion preferences. Delivered an offline preview and a classic WordPress theme. No commercial client affiliation. Theme content is maintained in templates; this demo does not claim a custom visual editor.

## Atelier Enquiries — custom WordPress form plugin
Self-initiated functional plugin. Built a shortcode enquiry form, configurable recipient, server-side input validation, consent check, nonce verification, honeypot and basic submission throttling. Email notifications use the site's WordPress mail transport. Delivered source, installable package and an interactive frontend preview. Live WordPress installation and email delivery are pending staging verification.

## Suggested application wording
I've attached two self-initiated demos: a responsive service website with an installable WordPress theme, and a custom WordPress enquiry plugin. They show my approach to interface implementation and small functional extensions. The previews run locally; I can adapt the source to an agreed client brief and test the WordPress integration on staging.
