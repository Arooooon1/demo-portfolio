<?php
/**
 * Plugin Name: Atelier Enquiries
 * Description: Accessible enquiry shortcode with validation, abuse controls and configurable email recipient. Portfolio demo.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * License: GPL-2.0-or-later
 */
if (!defined('ABSPATH')) { exit; }
function ae_value($key) { return isset($_POST[$key]) && is_string($_POST[$key]) ? wp_unslash($_POST[$key]) : ''; }
function ae_return($status) {
    $return = esc_url_raw(ae_value('ae_return'));
    $return = wp_validate_redirect($return, home_url('/'));
    wp_safe_redirect(add_query_arg('ae_status', $status, remove_query_arg('ae_status', $return)).'#ae-form'); exit;
}
add_action('admin_menu', function () { add_options_page('Atelier Enquiries','Atelier Enquiries','manage_options','atelier-enquiries','ae_settings'); });
add_action('admin_init', function () {
    register_setting('atelier_enquiries', 'ae_recipient', array('type'=>'string','sanitize_callback'=>'ae_recipient_clean','default'=>''));
});
function ae_recipient_clean($value) {
    if (!is_string($value) || !is_email(trim($value))) { add_settings_error('ae_recipient','ae_invalid_email','Enter a valid recipient email.'); return get_option('ae_recipient',''); }
    return sanitize_email($value);
}
function ae_settings() {
    if (!current_user_can('manage_options')) { return; }
    ?><div class="wrap"><h1>Atelier Enquiries</h1><p>Add <code>[atelier_enquiry]</code> to a page. Configure and test your mail transport before production use.</p><?php settings_errors(); ?><form method="post" action="options.php"><?php settings_fields('atelier_enquiries'); ?><label for="ae-recipient">Notification recipient</label><input id="ae-recipient" type="email" name="ae_recipient" value="<?php echo esc_attr(get_option('ae_recipient', get_option('admin_email'))); ?>" required><?php submit_button(); ?></form></div><?php
}
add_action('wp_enqueue_scripts', function () { wp_register_style('atelier-enquiries', plugins_url('assets/form.css',__FILE__),array(),'1.0.0'); });
add_shortcode('atelier_enquiry', function () {
    wp_enqueue_style('atelier-enquiries');
    $statuses = array('sent'=>'Your enquiry was accepted for email delivery. Inbox delivery is not guaranteed.','invalid'=>'Please check the fields and consent, then try again.','expired'=>'This form expired. Refresh the page and try again.','limited'=>'Please wait a minute before submitting another enquiry.','error'=>'The email request failed. Please try again later.');
    $status = isset($_GET['ae_status']) && is_string($_GET['ae_status']) ? sanitize_key(wp_unslash($_GET['ae_status'])) : '';
    ob_start(); ?><form id="ae-form" class="ae-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
    <?php if (isset($statuses[$status])) : ?><p class="ae-status" role="status"><?php echo esc_html($statuses[$status]); ?></p><?php endif; ?>
    <input type="hidden" name="action" value="ae_submit"><input type="hidden" name="ae_return" value="<?php echo esc_url(get_permalink()); ?>"><?php wp_nonce_field('ae_submit','ae_nonce'); ?>
    <div class="ae-honey" aria-hidden="true"><label>Leave empty<input name="website_url" tabindex="-1" autocomplete="off"></label></div>
    <label>Your name<input name="name" autocomplete="name" required maxlength="100"></label>
    <label>Email address<input name="email" type="email" autocomplete="email" required maxlength="254"></label>
    <label>Project type<select name="project"><option value="website">Website project</option><option value="integration">Form or integration</option><option value="other">Other enquiry</option></select></label>
    <label>Tell us about your project<textarea name="message" required minlength="15" maxlength="3000"></textarea></label>
    <label class="ae-consent"><input type="checkbox" name="consent" value="1" required><span>I agree to have my enquiry processed to receive a reply.</span></label>
    <button type="submit">Send enquiry</button></form><?php return ob_get_clean();
});
add_action('admin_post_ae_submit','ae_submit');
add_action('admin_post_nopriv_ae_submit','ae_submit');
function ae_submit() {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { wp_die('Method not allowed.', '', array('response'=>405)); }
    if (!wp_verify_nonce(ae_value('ae_nonce'),'ae_submit')) { ae_return('expired'); }
    if (ae_value('website_url') !== '') { ae_return('invalid'); }
    $name = sanitize_text_field(ae_value('name')); $email_raw = trim(ae_value('email')); $email = sanitize_email($email_raw);
    $message = sanitize_textarea_field(ae_value('message')); $project = ae_value('project');
    if ($name === '' || strlen($name)>100 || strlen($email_raw)>254 || !is_email($email_raw) || strlen($message)<15 || strlen($message)>3000 || !in_array($project,array('website','integration','other'),true) || ae_value('consent') !== '1') { ae_return('invalid'); }
    $ip = isset($_SERVER['REMOTE_ADDR']) && is_string($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
    $key = 'ae_rate_'.hash_hmac('sha256',$ip,wp_salt('nonce'));
    if (get_transient($key)) { ae_return('limited'); }
    set_transient($key,1,60);
    $recipient = get_option('ae_recipient',''); if (!$recipient) { $recipient = get_option('admin_email'); }
    if (!is_email($recipient)) { ae_return('error'); }
    $body = "Name: ".$name."\nEmail: ".$email."\nProject: ".$project."\n\n".$message;
    $sent = wp_mail($recipient,'New website enquiry',$body,array('Reply-To: '.$email));
    ae_return($sent ? 'sent' : 'error');
}
