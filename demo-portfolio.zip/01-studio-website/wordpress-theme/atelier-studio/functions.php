<?php
if (!defined('ABSPATH')) { exit; }
add_action('after_setup_theme', function () { add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('html5', array('search-form','comment-form','comment-list','gallery','caption','style','script')); });
add_action('wp_enqueue_scripts', function () { wp_enqueue_style('atelier-studio', get_stylesheet_uri(), array(), '1.0.0'); wp_enqueue_script('atelier-studio', get_template_directory_uri().'/assets/app.js', array(), '1.0.0', true); });
