# Verification / 2026-10-13

Passed automated browser checks in Microsoft Edge, opening local HTML files:
- Desktop 1440×1000 and mobile 390×844.
- Project filter switches visible cards correctly.
- Mobile navigation opens and closes after a link is selected.
- Empty form does not show success; valid form shows an explicitly simulated confirmation.
- No horizontal overflow on tested mobile layouts.
- No JavaScript runtime errors across the gallery and both demos.
- Reduced-motion variant inspected in saved screenshots.

Screenshots visually reviewed: studio-desktop.png and plugin-mobile.png.
Not verified: PHP syntax with a PHP interpreter, WordPress activation, server-side submission and actual mail delivery. See README.md for the staging checklist.
